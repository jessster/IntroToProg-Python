#-------------------------------------------------#
# Title: Working with pickling and exceptions - Todo list with priorities
# Dev:   Jess Mauer
# Date:  May 13, 2018
# ChangeLog: (Who, When, What)
#   Jess Mauer, 5/13/2018, Created initial code
#-------------------------------------------------#


# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can pickle list to file (Step 6)

# ---- data code ----
# code starts with a try statement so any errors are handled as exceptions at the bottom.
try:
    objFileName = open("todolist.txt", "r")
    strData = ""
    dicRow = {}
    lstTable = []


# import the pickle module to save list to a binary file
    import pickle

#---- Create the data class-----#
    # ---- processing code ----
    class TodoList(object):

        @staticmethod
        def loadData(file, fileTable=None):
            """ Loads the current data from the text file into dictionary rows in a table"""
            for line in file:
                fileRow = line.split(",")
                fileRow = {"Task": fileRow[0].strip(), "Priority": fileRow[1].strip()}
                fileTable.append(fileRow)
            return fileTable

        @staticmethod
        def closeFile(file):
            """ Closes the open file """
            file.close()
            return

        @staticmethod
        def menu(choice=None):
            """ Presents user with menu of options"""

            print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            choice = int(input("Which option would you like to perform? [1 to 5] - "))
            if choice > 5:
                print("That number is too big, please enter a number 1 - 5")
                TodoList.menu()
            elif choice < 1:
                print("That number is too little, please enter a number 1 - 5")
                TodoList.menu()
            else:
                return choice


        @staticmethod
        def currentItems(fileTable):
            """ Prints out the current items in the list"""
            for line in fileTable:
                print(line["Task"] + " - " + line["Priority"])
            return

        @staticmethod
        def addTask(newTask=None, priority=None, newItem=None):
            """ Allows user to add a new task"""
            newTask = str(input("Please input the task: "))
            priority = str(input("Please input priority: "))
            newItem = {"Task": newTask, "Priority": priority}
            return newItem

        @staticmethod
        def showKeys(fileTable):
            """Shows user which tasks are avaliable"""
            itemNum = 1
            for line in fileTable:
                print(str(itemNum) + " - " + line["Task"])
                itemNum = itemNum + 1
            return

        @staticmethod
        def removeTask(length,fileTable):
            """ Allows user to remove a task"""
            deleteTask = int(input("\nPlease enter number: "))
            if deleteTask < 1:
                print("Please enter a positive number")
                TodoList.removeTask(length,fileTable)
            elif deleteTask > length:
                print("Please enter a lower number")
                TodoList.removeTask(length, fileTable)
            deleteTask = deleteTask - 1
            del fileTable[deleteTask]
            return

        @staticmethod
        def saveList(fileTable, objFileName=None):
            """ Allows the user to save the file"""
            objFileName = open("todolist.txt", "w")
            objFileName.write(str(fileTable))
            objFileName.close()

        @staticmethod
        def pickleTodo(table):
            f = open("pickles_todo.dat", "wb")
            pickle.dump(table, f)
            f.close()


#--- use the class----#
    # -- Processing --#
    # Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
    TodoList.loadData(objFileName, lstTable)
    TodoList.closeFile(objFileName)

    # Step 2
    # Display a menu of choices to the user
    while (True):

        strChoice = TodoList.menu()
        print()  # adding a new line

        # Step 3
        # Display all todo items to user
        if (strChoice == 1):
            print(TodoList.currentItems(lstTable))
            continue

        # Step 4
        # Add a new item to the list/Table
        elif (strChoice == 2):
            lstTable.append(TodoList.addTask())
            print(TodoList.currentItems(lstTable))
            continue

        # Step 5
        # Remove a new item to the list/Table
        elif (strChoice == 3):

            print("\nWhich item would you like to remove? ")
            TodoList.showKeys(lstTable)
            tableLen = len(lstTable)
            TodoList.removeTask(tableLen,lstTable)
            print(TodoList.currentItems(lstTable))
            continue

        # Step 6
        # Pickels tasks to a binary file
        elif (strChoice == 4):
            TodoList.pickleTodo(lstTable)
            continue

        # Step 7
        # Exit program
        elif (strChoice == 5):
            break


# catches an errors if the file has not been created
except FileNotFoundError as e:
    print("You must put a todo list binary file in the same folder as this script")

# catches an error if a user doesn't enter a number
except ValueError as e:
    print("Please enter an integer, not a string")

# catches an error if the user enters a number that's not in the list
except IndexError as e:
    print("You didn't pick a number in the list")

# catches any other error
except Exception as e:
    print("Some other error happened. ")
