#-------------------------------------------------#
# Title: Working with Functions and Classes - Todo list wtih priorities
# Dev:   Jess Mauer
# Date:  May 11, 2018
# ChangeLog: (Who, When, What)
#   Jess Mauer, 5/11/2018, Created initial code
#   Jess Mauer, 5/12/2018, completed version 1
#-------------------------------------------------#

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#---- data code ----
objFileName = open("/Users/jessmauer/todolist.txt", "r")
strData = ""
dicRow = {}
lstTable = []

#---- processing code ----
class TodoList(object):

    @staticmethod
    def loadData(file,fileTable=None):
        """ Loads the current data from the text file into dictionary rows in a table"""
        for line in file:
            fileRow = line.split(",")
            fileRow = {"Task":fileRow[0].strip(), "Priority":fileRow[1].strip()}
            fileTable.append(fileRow)
        return fileTable

    @staticmethod
    def closeFile(file):
        """ Closes the open file """
        file.close()
        return

    @staticmethod
    def currentItems(fileTable):
        """ Prints out the current items in the list"""
        for line in fileTable:
            print(line["Task"] + " - " + line["Priority"])
        return

    @staticmethod
    def addTask(newTask=None,priority=None,newItem=None):
        """ Allows user to add a new task"""
        newTask = str(input("Please input the task: "))
        priority = str(input("Please input priority: "))
        newItem = {"Task": newTask, "Priority": priority}
        return newItem

    @staticmethod
    def showKeys(fileTable):
        """Shows user which tasks are avaliable"""
        itemNum = 1
        for line in fileTable:
            print(str(itemNum) + " - " + line["Task"])
            itemNum = itemNum + 1
        return

    @staticmethod
    def removeTask(deleteTask,fileTable):
        """ Allows user to remove a task"""
        deleteTask = deleteTask - 1
        del fileTable[deleteTask]
        return

    @staticmethod
    def saveList(fileTable,objFileName=None):
        """ Allows the user to save the file"""
        objFileName = open("/Users/jessmauer/todolist.txt", "w")
        objFileName.write(str(fileTable))
        objFileName.close()

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
TodoList.loadData(objFileName,lstTable)
TodoList.closeFile(objFileName)

# Step 2
# Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

# Step 3
# Display all todo items to user
    if (strChoice.strip() == '1'):
        print(TodoList.currentItems(lstTable))
        continue

# Step 4
# Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        lstTable.append(TodoList.addTask())
        print(TodoList.currentItems(lstTable))
        continue

# Step 5
# Remove a new item to the list/Table
    elif(strChoice == '3'):

        print("\nWhich item would you like to remove? ")
        TodoList.showKeys(lstTable)

        deleteItem = int(input("\nPlease enter item: "))
        TodoList.removeTask(deleteItem,lstTable)
        print(TodoList.currentItems(lstTable))
        continue

# Step 6
# Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        TodoList.saveList(lstTable)
        continue

# Step 7
# Exit program
    elif (strChoice == '5'):
        break